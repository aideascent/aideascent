@component('mail::message')
    {!! $message !!}
@endcomponent