<ul>
    <li><a href="{{ route('customer.dashboard') }}" class="btn btn-md btn-block btn-dark">Dashboard</a></li>
	<li><a href="{{ route('customer.order') }}" class="btn btn-md btn-block btn-dark">Orders</a></li>
	<li><a href="{{ route('customer.profile_change') }}" class="btn btn-md btn-block btn-dark">Edit Profile</a></li>
	<li><a href="{{ route('customer.password_change') }}" class="btn btn-md btn-block btn-dark">Edit Password</a></li>
    <li><a href="{{ route('customer.logout') }}" class="btn btn-md btn-block btn-dark">Logout</a></li>
</ul>