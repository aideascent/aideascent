<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class WhyChooseItem extends Model
{
    protected $fillable = [
        'name',
        'description',
        'photo'
    ];

}
