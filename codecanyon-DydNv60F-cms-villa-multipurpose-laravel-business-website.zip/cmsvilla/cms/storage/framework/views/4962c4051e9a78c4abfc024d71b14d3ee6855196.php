
<?php $__env->startSection('admin_content'); ?>
    <h1 class="h3 mb-3 text-gray-800">Dynamic Pages</h1>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 mt-2 font-weight-bold text-primary">View Dynamic Pages</h6>
            <div class="float-right d-inline">
                <a href="<?php echo e(route('admin.dynamic_page.create')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Add New</a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>SL</th>
                        <th>Banner</th>
                        <th>Dynamic Page Name</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $dynamic_page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><img src="<?php echo e(asset('public/uploads/'.$row->dynamic_page_banner)); ?>" alt="" class="w_300"></td>
                            <td><?php echo e($row->dynamic_page_name); ?></td>
                            <td>
                                <a href="<?php echo e(URL::to('admin/dynamic-page/edit/'.$row->id)); ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></a>
                                <a href="<?php echo e(URL::to('admin/dynamic-page/delete/'.$row->id)); ?>" class="btn btn-danger btn-sm" onClick="return confirm('Are you sure?');"><i class="fas fa-trash-alt"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cmsvilla\resources\views/admin/dynamic_page/index.blade.php ENDPATH**/ ?>