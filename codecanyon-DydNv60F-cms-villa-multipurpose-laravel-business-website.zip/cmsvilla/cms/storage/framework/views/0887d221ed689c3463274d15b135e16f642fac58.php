
<?php $__env->startSection('admin_content'); ?>
    <h1 class="h3 mb-3 text-gray-800">Edit Profile</h1>

    <div class="row">
        <div class="col-md-6">
            <form action="<?php echo e(url('admin/profile-change/update')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 mt-2 font-weight-bold text-primary">Edit Profile</h6>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">Name *</label>
                            <input type="text" name="name" class="form-control" value="<?php echo e($admin_data->name); ?>" autofocus>
                        </div>
                        <div class="form-group">
                            <label for="">Email Address *</label>
                            <input type="text" name="email" class="form-control" value="<?php echo e($admin_data->email); ?>">
                        </div>
                        <button type="submit" class="btn btn-success">Update</button>
                    </div>
                </div>
            </form>        
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cmsvilla\resources\views/admin/auth/profile_change.blade.php ENDPATH**/ ?>