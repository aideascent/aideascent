<?php $__env->startSection('content'); ?>
<div class="slider">
    <div class="slide-carousel owl-carousel">

        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="slider-item" style="background-image:url(<?php echo e(asset('public/uploads/'.$row->slider_photo)); ?>);">
            <div class="slider-bg"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-7 col-sm-12">
                        <div class="slider-table">
                            <div class="slider-text">
                                <div class="text-animated">
                                    <h1><?php echo e($row->slider_heading); ?></h1>
                                </div>
                                <div class="text-animated">
                                    <p>
                                        <?php echo nl2br(e($row->slider_text)); ?>

                                    </p>
                                </div>
                                <div class="text-animated">
                                    <ul>
                                        <li><a href="<?php echo e($row->slider_button_url); ?>"><?php echo e($row->slider_button_text); ?></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>


<?php if($page_home->why_choose_status == 'Show'): ?>
<div class="feature">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="heading wow fadeInUp">
                    <h2><?php echo e($page_home->why_choose_title); ?></h2>
                    <h3><?php echo e($page_home->why_choose_subtitle); ?></h3>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $why_choose_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="feature-item wow fadeInUp">
                    <div class="icon">
                        <img src="<?php echo e(asset('public/uploads/'.$row->photo)); ?>" alt="">
                    </div>
                    <h4><?php echo e($row->name); ?></h4>
                    <p>
                        <?php echo nl2br(e($row->description)); ?>

                    </p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?>


<?php if($page_home->special_status == 'Show'): ?>
<div class="special" style="background-image: url(<?php echo e(asset('public/uploads/'.$page_home->special_bg)); ?>);">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-6 wow fadeInLeft">
                <h2><?php echo e($page_home->special_title); ?></h2>
                <h3><?php echo e($page_home->special_subtitle); ?></h3>
                <p>
                    <?php echo nl2br(e($page_home->special_content)); ?>

                </p>
                <div class="read-more">
                    <a href="<?php echo e($page_home->special_btn_url); ?>" class="btn btn-primary btn-arf"><?php echo e($page_home->special_btn_text); ?></a>
                </div>
            </div>
            <div class="col-md-6 wow fadeInRight">
                <div class="video-section" style="background-image: url(<?php echo e(asset('public/uploads/'.$page_home->special_video_bg)); ?>)">
                    <div class="bg video-section-bg"></div>
                    <div class="video-button-container">
                        <a class="video-button" href="https://www.youtube.com/watch?v=<?php echo e($page_home->special_yt_video); ?>"><span></span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>


<?php if($page_home->service_status == 'Show'): ?>
<div class="service">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="heading wow fadeInUp">
                    <h2><?php echo e($page_home->service_title); ?></h2>
                    <h3><?php echo e($page_home->service_subtitle); ?></h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="service-carousel owl-carousel">
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="service-item wow fadeInUp">
                        <div class="photo">
                            <a href="<?php echo e(url('service/'.$row->slug)); ?>"><img src="<?php echo e(asset('public/uploads/'.$row->photo)); ?>" alt=""></a>
                        </div>
                        <div class="text">
                            <h3><a href="<?php echo e(url('service/'.$row->slug)); ?>"><?php echo e($row->name); ?></a></h3>
                            <p>
                                <?php echo nl2br(e($row->short_description)); ?>

                            </p>
                            <div class="read-more">
                                <a href="<?php echo e(url('service/'.$row->slug)); ?>">Read More</a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>


<?php if($page_home->testimonial_status == 'Show'): ?>
<div class="testimonial" style="background-image: url(<?php echo e(asset('public/uploads/'.$page_home->testimonial_bg)); ?>);">
    <div class="testimonial-bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="heading wow fadeInUp">
                    <h2><?php echo e($page_home->testimonial_title); ?></h2>
                    <h3><?php echo e($page_home->testimonial_subtitle); ?></h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="testimonial-carousel owl-carousel">
                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="testimonial-item wow fadeInUp">
                        <div class="photo">
                            <img src="<?php echo e(asset('public/uploads/'.$row->photo)); ?>" alt="">
                        </div>
                        <div class="text">
                            <p>
                                <?php echo nl2br(e($row->comment)); ?>

                            </p>
                            <h3><?php echo e($row->name); ?></h3>
                            <h4><?php echo e($row->designation); ?></h4>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>


<?php if($page_home->project_status == 'Show'): ?>
<div class="project">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="heading wow fadeInUp">
                    <h2><?php echo e($page_home->project_title); ?></h2>
                    <h3><?php echo e($page_home->project_subtitle); ?></h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="project-carousel owl-carousel">
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="project-item wow fadeInUp">
                        <div class="photo">
                            <a href="<?php echo e(url('project/'.$row->project_slug)); ?>"><img src="<?php echo e(asset('public/uploads/'.$row->project_featured_photo)); ?>" alt=""></a>
                        </div>
                        <div class="text">
                            <h3><a href="<?php echo e(url('project/'.$row->project_slug)); ?>"><?php echo e($row->project_name); ?></a></h3>
                            <p>
                                <?php echo nl2br(e($row->project_content_short)); ?>

                            </p>
                            <div class="read-more">
                                <a href="<?php echo e(url('project/'.$row->project_slug)); ?>">Read More</a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>


<?php if($page_home->team_member_status == 'Show'): ?>
<div class="team bg-lightblue">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="heading wow fadeInUp">
                    <h2><?php echo e($page_home->team_member_title); ?></h2>
                    <h3><?php echo e($page_home->team_member_subtitle); ?></h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="team-carousel owl-carousel">

                    <?php $__currentLoopData = $team_members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="team-item wow fadeInUp">
                        <div class="team-photo">
                            <a href="<?php echo e(url('team-member/'.$row->slug)); ?>" class="team-photo-anchor">
                                <img src="<?php echo e(asset('public/uploads/'.$row->photo)); ?>" alt="Team Member Photo">
                            </a>
                        </div>
                        <div class="team-text">
                            <h4><a href="<?php echo e(url('team-member/'.$row->slug)); ?>"><?php echo e($row->name); ?></a></h4>
                            <p><?php echo e($row->designation); ?></p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>



<?php if($page_home->appointment_status == 'Show'): ?>
<div class="cta" style="background-image: url(<?php echo e(asset('public/uploads/'.$page_home->appointment_bg)); ?>);">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="cta-box text-center">
                    <h2><?php echo e($page_home->appointment_title); ?></h2>
                    <p class="mt-3">
                        <?php echo nl2br(e($page_home->appointment_text)); ?>

                    </p>
                    <a href="<?php echo e($page_home->appointment_btn_url); ?>" class="btn btn-primary"><?php echo e($page_home->appointment_btn_text); ?></a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>



<?php if($page_home->latest_blog_status == 'Show'): ?>
<div class="blog-area">
    <div class="container wow fadeIn">

        <div class="row">
            <div class="col-md-12">
                <div class="heading wow fadeInUp">
                    <h2><?php echo e($page_home->latest_blog_title); ?></h2>
                    <h3><?php echo e($page_home->latest_blog_subtitle); ?></h3>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="blog-carousel owl-carousel">

                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="blog-item wow fadeInUp">
                        <a href="<?php echo e(url('blog/'.$row->blog_slug)); ?>">
                            <div class="blog-image">
                                <img src="<?php echo e(asset('public/uploads/'.$row->blog_photo)); ?>" alt="Blog Image">
                                <div class="date">
                                    <h3>03</h3>
                                    <h4>Apr</h4>
                                </div>
                            </div>
                        </a>
                        <div class="blog-text">
                            <h3><a href="<?php echo e(url('blog/'.$row->blog_slug)); ?>"><?php echo e($row->blog_title); ?></a></h3>
                            <p>
                                <?php echo nl2br(e($row->blog_content_short)); ?>

                            </p>
                            <div class="read-more">
                                <a href="<?php echo e(url('blog/'.$row->blog_slug)); ?>">Read More</a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>


<?php if($page_home->newsletter_status == 'Show'): ?>
<div class="newsletter-area" style="background-image: url(<?php echo e(asset('public/uploads/'.$page_home->newsletter_bg)); ?>);">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 newsletter">
                <div class="newsletter-text wow fadeInUp">
                    <h2><?php echo e($page_home->newsletter_title); ?></h2>
                    <p>
                        <?php echo nl2br(e($page_home->newsletter_text)); ?>

                    </p>
                </div>
                <div class="newsletter-button wow fadeInUp">
                    <form action="<?php echo e(route('front.subscription')); ?>" method="post" class="frm_newsletter justify-content-center">
                        <?php echo csrf_field(); ?>
                        <input type="text" placeholder="Enter Your Email" name="subs_email">
                        <input type="submit" value="Submit">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cmsvilla\resources\views/pages/index.blade.php ENDPATH**/ ?>