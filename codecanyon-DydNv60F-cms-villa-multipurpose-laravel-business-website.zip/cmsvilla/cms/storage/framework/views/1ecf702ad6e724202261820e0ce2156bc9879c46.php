<?php $__env->startSection('content'); ?>
    <div class="page-banner" style="background-image: url(<?php echo e(asset('public/uploads/'.$g_setting->banner_blog)); ?>)">
        <div class="bg-page"></div>
        <div class="text">
            <h1><?php echo e($category_single->category_name); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($category_single->category_name); ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="single-section">

                        <?php $__currentLoopData = $blog_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="blog-item">
                                <div class="featured-photo">
                                    <a href="<?php echo e(url('blog/'.$row->blog_slug)); ?>"><img src="<?php echo e(asset('public/uploads/'.$row->blog_photo)); ?>"></a>
                                </div>
                                <div class="text">
                                    <h2><a href="<?php echo e(url('blog/'.$row->blog_slug)); ?>"><?php echo e($row->blog_title); ?></a></h2>
                                    <p>
                                        <?php echo nl2br(e($row->blog_content_short)); ?>

                                    </p>
                                    <div class="read-more">
                                        <a href="<?php echo e(url('blog/'.$row->blog_slug)); ?>">Read More</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <div>
                        <?php echo e($blog_items->links()); ?>

                    </div>
                </div>
                <div class="col-md-4">
                    <?php echo $__env->make('layouts.sidebar_blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\phpscriptpoint\cmsvilla\cmsvilla\cms\resources\views/pages/category.blade.php ENDPATH**/ ?>