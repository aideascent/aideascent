<?php $__env->startSection('content'); ?>
    <div class="page-banner" style="background-image: url(<?php echo e(asset('public/uploads/'.$g_setting->banner_blog_detail)); ?>)">
        <div class="bg-page"></div>
        <div class="text">
            <h1><?php echo e($blog_detail->blog_title); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('front.blogs')); ?>">Blogs</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($blog_detail->blog_title); ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="single-section">
                        <div class="featured-photo">
                            <img src="<?php echo e(asset('public/uploads/'.$blog_detail->blog_photo)); ?>">
                        </div>
                        <div class="text">
                            <h2><?php echo e($blog_detail->blog_title); ?></h2>
                            <h3>
                                Posted on: <?php echo e(\Carbon\Carbon::parse($blog_detail->created_at)->format('d M, Y')); ?>

                            </h3>
                            <?php echo $blog_detail->blog_content; ?>

                        </div>

                        <h2 class="mt_35">Share This</h2>
                        <div class="sharethis-inline-share-buttons"></div>


                        <!-- Comment Section Started -->
                        <hr class="mt_50">
                        <div class="comment mt_50">

                            <h2 class="mb_40">Comments (<?php echo e(count($comments)); ?>)</h2>

                            <?php if(count($comments) == 0): ?>
                                <div class="text-danger">No Comment Found</div>
                            <?php else: ?>
                                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="comment-item">
                                        <div class="text">
                                            <h4><?php echo e($loop->iteration . '. ' . $row->person_name); ?></h4>
                                            <div class="date"><?php echo e(\Carbon\Carbon::parse($row->created_at)->format('d M, Y')); ?></div>
                                            <div class="des">
                                                <p>
                                                    <?php echo nl2br(e($row->person_message)); ?>

                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <hr class="mt_50">

                            <h2 class="mt_35">Post Your Comment</h2>
                            <form action="<?php echo e(route('front.comment')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="blog_id" value="<?php echo e($blog_detail->id); ?>">
                                <input type="hidden" name="blog_slug" value="<?php echo e($blog_detail->blog_slug); ?>">
                                <input type="hidden" name="comment_status" value="Pending">
                                <div class="row mb_20">
                                    <div class="col">
                                        <input type="text" class="form-control" placeholder="Name" name="person_name">
                                    </div>
                                    <div class="col">
                                        <input type="email" class="form-control" placeholder="Email Address" name="person_email">
                                    </div>
                                </div>
                                <div class="row mb_20">
                                    <div class="col">
                                        <textarea name="person_message" class="form-control h-200" cols="30" rows="10" placeholder="Comment"></textarea>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <button type="submit" class="btn btn-primary">Post Comment</button>
                                    </div>
                                </div>
                            </form>

                        </div>
                        <!-- Comment Section End -->



                    </div>
                </div>
                <div class="col-md-4">
                    <?php echo $__env->make('layouts.sidebar_blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\phpscriptpoint\cmsvilla\cmsvilla\cms\resources\views/pages/blog_detail.blade.php ENDPATH**/ ?>