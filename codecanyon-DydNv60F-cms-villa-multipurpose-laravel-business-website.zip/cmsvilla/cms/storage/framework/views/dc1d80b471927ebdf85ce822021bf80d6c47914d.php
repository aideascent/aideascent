<?php $__env->startSection('content'); ?>
    <div class="page-banner" style="background-image: url(<?php echo e(asset('public/uploads/'.$g_setting->banner_team_member)); ?>)">
        <div class="bg-page"></div>
        <div class="text">
            <h1><?php echo e($team_member->name); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($team_member->name); ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $team_member->detail; ?>

                </div>
            </div>
            <div class="row team pt_0 pb_40">
                <?php $__currentLoopData = $team_members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-6 col-sm-12 wow fadeInUp">
                        <div class="team-item">
                            <div class="team-photo">
                                <a href="<?php echo e(url('team-member/'.$row->slug)); ?>" class="team-photo-anchor">
                                    <img src="<?php echo e(asset('public/uploads/'.$row->photo)); ?>" alt="Team Member Photo">
                                </a>
                            </div>
                            <div class="team-text">
                                <h4><a href="<?php echo e(url('team-member/'.$row->slug)); ?>"><?php echo e($row->name); ?></a></h4>
                                <p><?php echo e($row->designation); ?></p>
                                <?php if($row->facebook != '' || $row->twitter != '' || $row->linkedin != '' || $row->youtube != '' || $row->instagram != ''): ?>
                                <div class="team-social">
                                    <ul>
                                        <?php if($row->facebook != ''): ?>
                                            <li><a href="<?php echo e($row->facebook); ?>" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                        <?php endif; ?>

                                        <?php if($row->twitter != ''): ?>
                                            <li><a href="<?php echo e($row->twitter); ?>" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                        <?php endif; ?>

                                        <?php if($row->linkedin != ''): ?>
                                            <li><a href="<?php echo e($row->linkedin); ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                                        <?php endif; ?>
                                        <?php if($row->youtube != ''): ?>
                                            <li><a href="<?php echo e($row->youtube); ?>" target="_blank"><i class="fab fa-youtube"></i></a></li>
                                        <?php endif; ?>
                                        <?php if($row->instagram != ''): ?>
                                            <li><a href="<?php echo e($row->instagram); ?>" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                        <?php endif; ?>

                                    </ul>
                                </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <?php echo e($team_members->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cmsvilla\resources\views/pages/team_members.blade.php ENDPATH**/ ?>