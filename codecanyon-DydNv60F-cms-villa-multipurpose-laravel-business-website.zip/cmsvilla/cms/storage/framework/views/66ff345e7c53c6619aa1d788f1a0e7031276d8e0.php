

<?php $__env->startSection('content'); ?>
    <div class="page-banner" style="background-image: url(<?php echo e(asset('public/uploads/'.$g_setting->banner_checkout)); ?>)">
        <div class="bg-page"></div>
        <div class="text">
            <h1>Checkout</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Checkout</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="page-content pt_50 pb_60">
        <div class="container">
            <div class="row cart">
                <div class="col-md-12 faq">
                    
                    
                    <div class="panel-group" id="accordion1" role="tablist" aria-multiselectable="true">

                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="heading1">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion1" href="#collapse1" aria-expanded="false" aria-controls="collapse1">
                                        Have a coupon?
                                    </a>
                                </h4>
                            </div>
                            <div id="collapse1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading1">
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <form action="<?php echo e(route('front.coupon_update')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <table>
                                                <tbody>
                                                    <tr>
                                                        <td class="text-left pr-1">
                                                            <input type="text" class="form-control" placeholder="Coupon Code" name="coupon_code">
                                                        </td>
                                                        <td class="text-left">
                                                            <button type="submit" class="btn btn-primary btn-block">Apply Coupon</button>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="heading2">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion1" href="#collapse2" aria-expanded="false" aria-controls="collapse2">
                                        Shipping Information
                                    </a>
                                </h4>
                            </div>
                            <div id="collapse2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading2">
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <tbody>
                                                <tr>
                                                    <td colspan="2" class="text-left table-top-bottom-no-border">
                                                        <form action="<?php echo e(route('front.shipping_update')); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php $i=0;  ?>
                                                            <?php $__currentLoopData = $shipping_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php $i++;  ?>
                                                                <?php if( !session()->get('shipping_id') ): ?>
                                                                    <?php if($i==1): ?>
                                                                        <?php $chk='checked'; ?>
                                                                    <?php else: ?>
                                                                        <?php $chk=''; ?>
                                                                    <?php endif; ?>
                                                                <?php else: ?>
                                                                    <?php if(session()->get('shipping_id') == $row->id): ?>
                                                                    
                                                                        <?php $chk='checked'; ?>
                                                                    
                                                                    <?php else: ?>
                                                                        <?php $chk=''; ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>

                                                                <div class="shipping-checkbox-container">
                                                                    <div class="form-check">
                                                                    <input class="form-check-input" type="radio" name="shipping_id" id="shipping_radio_<?php echo e($i); ?>" value="<?php echo e($row->id); ?>" <?php echo e($chk); ?>>
                                                                        <label class="form-check-label" for="shipping_radio_<?php echo e($i); ?>">
                                                                            <div class="heading">
                                                                                <?php echo e($row->shipping_name); ?>

                                                                                ($<span class="shipping_price"><?php echo e($row->shipping_cost); ?>)</span>
                                                                            </div>
                                                                            <div class="subheading">(<?php echo nl2br(e($row->shipping_text)); ?>)</div>
                                                                        </label>
                                                                    </div>
                                                                </div>

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <input type="submit" class="btn btn-primary" value="Apply Shipping">
                                                        </form>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        



                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="heading3">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion1" href="#collapse3" aria-expanded="false" aria-controls="collapse3">
                                        Cart Details
                                    </a>
                                </h4>
                            </div>
                            <div id="collapse3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading3">
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <tbody>
                                                <?php
                                                    $arr_cart_product_id = array();
                                                    $arr_cart_product_qty = array();
                                                ?>
                                                
                                                <?php $i=0; ?>
                                                <?php $__currentLoopData = session()->get('cart_product_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php 
                                                        $arr_cart_product_id[$i] = $value;
                                                        $i++;
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                                                <?php $i=0; ?>
                                                <?php $__currentLoopData = session()->get('cart_product_qty'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $arr_cart_product_qty[$i] = $value;
                                                        $i++;
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                                                <?php $tot1 = 0; ?>
                                                
                                                <?php for($i=0;$i<count($arr_cart_product_id);$i++): ?>
                
                                                    <?php
                                                        $product_detail = DB::table('products')->where('id', $arr_cart_product_id[$i])->first();
                                                        $product_name = $product_detail->product_name;
                                                        $product_slug = $product_detail->product_slug;
                                                        $product_current_price = $product_detail->product_current_price;
                                                        $product_featured_photo = $product_detail->product_featured_photo;
                                                    ?>
                
                                                    <tr>
                                                        <td class="text-left">
                                                            <?php echo e($product_name); ?> x <?php echo e($arr_cart_product_qty[$i]); ?>

                                                        </td>
                                                        <td class="text-right">
                                                            <?php $subtotal = $product_current_price * $arr_cart_product_qty[$i] ?>
                                                            $<?php echo e($subtotal); ?>

                                                        </td>
                                                    </tr>
                                                    
                                                    <?php
                                                        $tot1 = $tot1+$subtotal; 
                                                    ?>
                                                    
                                                <?php endfor; ?>
                
                                                <?php 
                                                    session()->put('subtotal', $tot1);
                                                ?>
                                                
                                                <tr>
                                                    <td class="text-left">Subtotal </td>
                                                    <td class="text-right">
                                                        $<span class="subtotal_price"><?php echo e(session()->get('subtotal')); ?></span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="text-left">
                                                        Coupon <span class="font-weight-bold"><?php if(session()->get('coupon_code')): ?> <?php echo e('('.session()->get('coupon_code').')'); ?> <?php endif; ?></span>
                                                    </td>
                                                    <td class="text-right">
                                                        <?php if(session()->get('coupon_amount')): ?>
                                                            (-) $<span class="coupon_amount"><?php echo e(session()->get('coupon_amount')); ?></span>
                                                        <?php else: ?>
                                                            <?php session()->put('coupon_amount', 0); ?>
                                                            (-) $<span class="coupon_amount"><?php echo e(session()->get('coupon_amount')); ?></span>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                
                                                <?php if(session()->get('shipping_id')): ?>
                                                <tr>
                                                    <?php
                                                        $shipping_info = DB::table('shippings')->where('id', session()->get('shipping_id'))->first();
                                                    ?>
                
                                                    <td class="text-left">
                                                        Shipping Information <br>(<span class="font-weight-bold"><?php echo e($shipping_info->shipping_name); ?> - <?php echo e($shipping_info->shipping_text); ?></span>)
                                                    </td>
                                                    <td class="text-right">
                                                        (+) $<span class=""><?php echo e(session()->get('shipping_cost')); ?></span>
                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                    
                                                <tr>
                                                    <td class="text-left">Total </td>
                                                    <td class="text-right">
                                                        
                                                        <?php if(!session()->get('coupon_amount')): ?>
                                                            <?php session()->put('coupon_amount', 0) ?>
                                                        <?php endif; ?>
                                                        
                                                        <?php if(session()->get('shipping_cost')): ?>
                                                            <?php 
                                                                $final_price = (session()->get('subtotal') + session()->get('shipping_cost'))-session()->get('coupon_amount'); 
                                                            ?>
                                                        <?php else: ?>
                                                            <?php
                                                                $final_price =session()->get('subtotal') - session()->get('coupon_amount');
                                                            ?>
                                                        <?php endif; ?>
                                                       
                                                        $<span class="total_price"><?php echo e($final_price); ?></span>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                    
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div><!-- //panel-group -->


                    <?php if(!session()->get('customer_id')): ?>
                    <form action="<?php echo e(route('customer.login_from_checkout_page.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="customer-info mb_30">                       
                            <div class="form-check mt_10 mb_10">
                                <input class="form-check-input" type="checkbox" id="returning_customer_action">
                                <label class="form-check-label" for="returning_customer_action">
                                    Returning Customer? Click here to login                            
                                </label>
                            </div>
                            <div class="returning-customer-login-section d_n">
                                <h4>Login</h4>
                                <div class="row mb_10">
                                    <div class="col">
                                        <input type="text" class="form-control" placeholder="Email Address" name="customer_email">
                                    </div>
                                    <div class="col">
                                        <input type="password" class="form-control" placeholder="Password" name="customer_password">
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary">Login</button>
                            </div>
                        </div>
                    </form>
                    <?php endif; ?>

                    <?php if(session()->get('customer_id')): ?>
                    <div class="existing-customer-container">
                        <h4>Existing Customer</h4>
                        <div class="row mb_30">
                            <div class="col">
                                <input type="text" class="form-control first_field" value="<?php echo e(session()->get('customer_name')); ?>" disabled>
                            </div>
                            <div class="col">
                                <input type="text" class="form-control second_field" value="<?php echo e(session()->get('customer_email')); ?>" disabled>
                            </div>
                        </div>      
                    </div>
                    <?php endif; ?>

                    <?php $temp_var = '';  ?>
                    <form action="<?php echo e(route('customer.billing_shipping_submit')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <h4>Billing Information</h4>
                        <div class="row mb_10">
                            <div class="col">
                                <?php if(session()->get('billing_name')): ?>
                                <?php $temp_var = session()->get('billing_name') ?>
                                <?php elseif(session()->get('customer_id')): ?>
                                <?php $temp_var = session()->get('customer_name') ?>
                                <?php endif; ?>
                                <input type="text" class="form-control" placeholder="Full Name" name="billing_name" value="<?php echo e($temp_var); ?>">
                            </div>
                            <div class="col">
                                <?php if(session()->get('billing_email')): ?>
                                <?php $temp_var = session()->get('billing_email') ?>
                                <?php elseif(session()->get('customer_id')): ?>
                                <?php $temp_var = session()->get('customer_email') ?>
                                <?php endif; ?>
                                <input type="text" class="form-control" placeholder="Email Address" name="billing_email" value="<?php echo e($temp_var); ?>">
                            </div>
                        </div>
                        <div class="row mb_10">
                            <div class="col">
                                <?php if(session()->get('billing_phone')): ?>
                                <?php $temp_var = session()->get('billing_phone') ?>
                                <?php elseif(session()->get('customer_id')): ?>
                                <?php $temp_var = session()->get('customer_phone') ?>
                                <?php endif; ?>
                                <input type="text" class="form-control" placeholder="Phone Number" name="billing_phone" value="<?php echo e($temp_var); ?>">
                            </div>
                            <div class="col">
                                <?php if(session()->get('billing_country')): ?>
                                <?php $temp_var = session()->get('billing_country') ?>
                                <?php elseif(session()->get('customer_id')): ?>
                                <?php $temp_var = session()->get('customer_country') ?>
                                <?php endif; ?>
                                <input type="text" class="form-control" placeholder="Country Name" name="billing_country" value="<?php echo e($temp_var); ?>">
                            </div>
                        </div>
                        <div class="row mb_10">
                            <div class="col">
                                <?php if(session()->get('billing_address')): ?>
                                <?php $temp_var = session()->get('billing_address') ?>
                                <?php elseif(session()->get('customer_id')): ?>
                                <?php $temp_var = session()->get('customer_address') ?>
                                <?php endif; ?>
                                <input type="text" class="form-control" placeholder="Address" name="billing_address" value="<?php echo e($temp_var); ?>">
                            </div>
                            <div class="col">
                                <?php if(session()->get('billing_state')): ?>
                                <?php $temp_var = session()->get('billing_state') ?>
                                <?php elseif(session()->get('customer_id')): ?>
                                <?php $temp_var = session()->get('customer_state') ?>
                                <?php endif; ?>
                                <input type="text" class="form-control" placeholder="State" name="billing_state" value="<?php echo e($temp_var); ?>">
                            </div>
                        </div>
                        <div class="row mb_10">
                            <div class="col">
                                <?php if(session()->get('billing_city')): ?>
                                <?php $temp_var = session()->get('billing_city') ?>
                                <?php elseif(session()->get('customer_id')): ?>
                                <?php $temp_var = session()->get('customer_city') ?>
                                <?php endif; ?>
                                <input type="text" class="form-control" placeholder="City" name="billing_city" value="<?php echo e($temp_var); ?>">
                            </div>
                            <div class="col">
                                <?php if(session()->get('billing_zip')): ?>
                                <?php $temp_var = session()->get('billing_zip') ?>
                                <?php elseif(session()->get('customer_id')): ?>
                                <?php $temp_var = session()->get('customer_zip') ?>
                                <?php endif; ?>
                                <input type="text" class="form-control" placeholder="Zip Code" name="billing_zip" value="<?php echo e($temp_var); ?>">
                            </div>
                        </div>
                        <div class="form-check mt_30 mb_10">
                            <input class="form-check-input" type="checkbox" id="click_shipping_same_check" name="name_click_shipping_same_check" <?php if(session()->get('name_click_shipping_same_check')): ?> checked  <?php endif; ?>>
                            <label class="form-check-label" for="click_shipping_same_check">
                                Ship to a different address?
                            </label>
                        </div>


                        <div class="shipping-info mt_15 <?php if(session()->get('name_click_shipping_same_check')): ?> d_b <?php else: ?> d_n <?php endif; ?>">
                            <h4>Shipping Information</h4>
                            <div class="row mb_10">
                                <div class="col">
                                    <?php if(session()->get('shipping_name')): ?>
                                    <?php $temp_var = session()->get('shipping_name') ?>
                                    <?php elseif(session()->get('customer_id')): ?>
                                    <?php $temp_var = session()->get('customer_name') ?>
                                    <?php endif; ?>
                                    <input type="text" class="form-control" placeholder="Full Name" name="shipping_name" value="<?php echo e($temp_var); ?>">
                                </div>
                                <div class="col">
                                    <?php if(session()->get('shipping_email')): ?>
                                    <?php $temp_var = session()->get('shipping_email') ?>
                                    <?php elseif(session()->get('customer_id')): ?>
                                    <?php $temp_var = session()->get('customer_email') ?>
                                    <?php endif; ?>
                                    <input type="text" class="form-control" placeholder="Email Address" name="shipping_email" value="<?php echo e($temp_var); ?>">
                                </div>
                            </div>
                            <div class="row mb_10">
                                <div class="col">
                                    <?php if(session()->get('shipping_phone')): ?>
                                    <?php $temp_var = session()->get('shipping_phone') ?>
                                    <?php elseif(session()->get('customer_id')): ?>
                                    <?php $temp_var = session()->get('customer_phone') ?>
                                    <?php endif; ?>
                                    <input type="text" class="form-control" placeholder="Phone Number" name="shipping_phone" value="<?php echo e($temp_var); ?>">
                                </div>
                                <div class="col">
                                    <?php if(session()->get('shipping_country')): ?>
                                    <?php $temp_var = session()->get('shipping_country') ?>
                                    <?php elseif(session()->get('customer_id')): ?>
                                    <?php $temp_var = session()->get('customer_country') ?>
                                    <?php endif; ?>
                                    <input type="text" class="form-control" placeholder="Country Name" name="shipping_country" value="<?php echo e($temp_var); ?>">
                                </div>
                            </div>
                            <div class="row mb_10">
                                <div class="col">
                                    <?php if(session()->get('shipping_address')): ?>
                                    <?php $temp_var = session()->get('shipping_address') ?>
                                    <?php elseif(session()->get('customer_id')): ?>
                                    <?php $temp_var = session()->get('customer_address') ?>
                                    <?php endif; ?>
                                    <input type="text" class="form-control" placeholder="Address" name="shipping_address" value="<?php echo e($temp_var); ?>">
                                </div>
                                <div class="col">
                                    <?php if(session()->get('shipping_state')): ?>
                                    <?php $temp_var = session()->get('shipping_state') ?>
                                    <?php elseif(session()->get('customer_id')): ?>
                                    <?php $temp_var = session()->get('customer_state') ?>
                                    <?php endif; ?>
                                    <input type="text" class="form-control" placeholder="State" name="shipping_state" value="<?php echo e($temp_var); ?>">
                                </div>
                            </div>
                            <div class="row mb_10">
                                <div class="col">
                                    <?php if(session()->get('shipping_city')): ?>
                                    <?php $temp_var = session()->get('shipping_city') ?>
                                    <?php elseif(session()->get('customer_id')): ?>
                                    <?php $temp_var = session()->get('customer_city') ?>
                                    <?php endif; ?>
                                    <input type="text" class="form-control" placeholder="City" name="shipping_city" value="<?php echo e($temp_var); ?>">
                                </div>
                                <div class="col">
                                    <?php if(session()->get('shipping_zip')): ?>
                                    <?php $temp_var = session()->get('shipping_zip') ?>
                                    <?php elseif(session()->get('customer_id')): ?>
                                    <?php $temp_var = session()->get('customer_zip') ?>
                                    <?php endif; ?>
                                    <input type="text" class="form-control" placeholder="Zip Code" name="shipping_zip" value="<?php echo e($temp_var); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row mb_10">
                            <div class="col">
                                <?php if(session()->get('order_note')): ?>
                                <?php $temp_var = session()->get('order_note') ?>
                                <?php else: ?>
                                <?php $temp_var = '' ?>
                                <?php endif; ?>
                                <textarea name="order_note" class="form-control h-100" cols="30" rows="10" placeholder="Order Notes"><?php echo e($temp_var); ?></textarea>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Continue to Payment</button>
                    </form>





                </div>
            </div>
        </div>
    </div>

    <script>
        (function($) {
            
            "use strict";
            
            $(document).ready(function() {
                $("#click_shipping_same_check").on('change',function(e) {
                    e.preventDefault();
                    if($(this).prop("checked") == true){
                        $('.shipping-info').attr('class','shipping-info mt_15 d_b');
                    } else {
                        $('.shipping-info').attr('class','shipping-info mt_15 d_n');
                    }
                });
        
                $("#returning_customer_action").on('change',function(e) {
                    e.preventDefault();
                    if($(this).prop("checked") == true){
                        $('.returning-customer-login-section').attr('class','returning-customer-login-section d_b');
                    } else {
                        $('.returning-customer-login-section').attr('class','returning-customer-login-section d_n');
                    }
                });
                
                $("#coupon_parent").on('change',function(e) {
                    e.preventDefault();
                    if($(this).prop("checked") == true){
                        $('.coupon_child').attr('class','coupon_child d_b');
                    } else {
                        $('.coupon_child').attr('class','coupon_child d_n');
                    }
                });
            });
        
        })(jQuery);
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cmsvilla\resources\views/pages/checkout.blade.php ENDPATH**/ ?>