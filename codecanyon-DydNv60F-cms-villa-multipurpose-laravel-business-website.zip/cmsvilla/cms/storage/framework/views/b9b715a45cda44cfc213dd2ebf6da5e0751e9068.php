<?php $__env->startSection('admin_content'); ?>
    <h1 class="h3 mb-3 text-gray-800">Edit Google Recaptcha Setting</h1>

    <form action="<?php echo e(url('admin/setting/general/googlerecaptcha/update')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <div class="row">
            <div class="col-md-6">
                <div class="card shadow mb-4">
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">Google Recaptcha Site Key</label>
                            <input type="text" name="google_recaptcha_site_key" class="form-control" value="<?php echo e($general_setting->google_recaptcha_site_key); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Google Recaptcha Status</label>
                            <div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="google_recaptcha_status" id="rr1" value="Show" <?php if($general_setting->google_recaptcha_status == 'Show'): ?> checked <?php endif; ?>>
                                    <label class="form-check-label font-weight-normal" for="rr1">Show</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="google_recaptcha_status" id="rr2" value="Hide" <?php if($general_setting->google_recaptcha_status == 'Hide'): ?> checked <?php endif; ?>>
                                    <label class="form-check-label font-weight-normal" for="rr2">Hide</label>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success">Update</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cmsvilla\resources\views/admin/general_setting/googlerecaptcha.blade.php ENDPATH**/ ?>