<ul>
    <li><a href="<?php echo e(route('customer.dashboard')); ?>" class="btn btn-md btn-block btn-dark">Dashboard</a></li>
	<li><a href="<?php echo e(route('customer.order')); ?>" class="btn btn-md btn-block btn-dark">Orders</a></li>
	<li><a href="<?php echo e(route('customer.profile_change')); ?>" class="btn btn-md btn-block btn-dark">Edit Profile</a></li>
	<li><a href="<?php echo e(route('customer.password_change')); ?>" class="btn btn-md btn-block btn-dark">Edit Password</a></li>
    <li><a href="<?php echo e(route('customer.logout')); ?>" class="btn btn-md btn-block btn-dark">Logout</a></li>
</ul><?php /**PATH D:\xampp\htdocs\cmsvilla\resources\views/layouts/sidebar_customer.blade.php ENDPATH**/ ?>