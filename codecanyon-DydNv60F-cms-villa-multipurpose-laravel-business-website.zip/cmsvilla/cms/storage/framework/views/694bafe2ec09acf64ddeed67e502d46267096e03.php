
<?php $__env->startSection('admin_content'); ?>
    <h1 class="h3 mb-3 text-gray-800">Footer Column Items</h1>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 mt-2 font-weight-bold text-primary">View Footer Column Items</h6>
            <div class="float-right d-inline">
                <a href="<?php echo e(route('admin.footer.create')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Add New</a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>SL</th>
                        <th>Text</th>
                        <th>URL</th>
                        <th>Order</th>
                        <th>Column Name</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $footer_columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($row->column_item_text); ?></td>
                            <td><?php echo e($row->column_item_url); ?></td>
                            <td><?php echo e($row->column_item_order); ?></td>
                            <td><?php echo e($row->column_name); ?></td>
                            <td>
                                <a href="<?php echo e(URL::to('admin/footer/edit/'.$row->id)); ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></a>
                                <a href="<?php echo e(URL::to('admin/footer/delete/'.$row->id)); ?>" class="btn btn-danger btn-sm" onClick="return confirm('Are you sure?');"><i class="fas fa-trash-alt"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cmsvilla\resources\views/admin/footer_column/index.blade.php ENDPATH**/ ?>