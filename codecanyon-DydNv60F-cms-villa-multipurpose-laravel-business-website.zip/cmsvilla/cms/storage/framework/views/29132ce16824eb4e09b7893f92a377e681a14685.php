<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Admin Panel</title>

    <?php echo $__env->make('admin.includes.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Sen:wght@400;700&display=swap" rel="stylesheet">

    <?php echo $__env->make('admin.includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        <?php
        $url = Request::path();
        $conName = explode('/',$url);
        if(!isset($conName[3]))
        {
            $conName[3] = '';
        }
        if(!isset($conName[2]))
        {
            $conName[2] = '';
        }
        ?>

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('admin.dashboard')); ?>">
            <div class="sidebar-brand-text mx-3">Admin Panel</div>
        </a>

        <!-- Divider -->
        <hr class="sidebar-divider my-0">


        <!-- Dashboard -->
        <li class="nav-item <?php if($conName[1] == 'dashboard'): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
                <i class="fas fa-fw fa-home"></i>
                <span>Dashboard</span>
            </a>
        </li>


        <!-- General Settings -->
        <li class="nav-item <?php if($conName[1] == 'setting' && $conName[2] == 'general'): ?> active <?php endif; ?>">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSetting" aria-expanded="true" aria-controls="collapseSetting">
                <i class="fas fa-cog"></i>
                <span>General Settings</span>
            </a>
            <div id="collapseSetting" class="collapse <?php if($conName[1] == 'setting' && $conName[2] == 'general'): ?> show <?php endif; ?>" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item <?php if($conName[3] == 'logo'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.general_setting.logo')); ?>">Logo</a>
                    <a class="collapse-item <?php if($conName[3] == 'favicon'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.general_setting.favicon')); ?>">Favicon</a>
                    <a class="collapse-item <?php if($conName[3] == 'loginbg'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.general_setting.loginbg')); ?>">Login Background</a>
                    <a class="collapse-item <?php if($conName[3] == 'topbar'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.general_setting.topbar')); ?>">Top Bar</a>
                    <a class="collapse-item <?php if($conName[3] == 'banner'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.general_setting.banner')); ?>">Banner</a>
                    <a class="collapse-item <?php if($conName[3] == 'footer'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.general_setting.footer')); ?>">Footer</a>
                    <a class="collapse-item <?php if($conName[3] == 'sidebar'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.general_setting.sidebar')); ?>">Sidebar</a>
                    <a class="collapse-item <?php if($conName[3] == 'color'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.general_setting.color')); ?>">Color</a>
                    <a class="collapse-item <?php if($conName[3] == 'preloader'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.general_setting.preloader')); ?>">Preloader</a>
                    <a class="collapse-item <?php if($conName[3] == 'stickyheader'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.general_setting.stickyheader')); ?>">Sticky Header</a>
                    <a class="collapse-item <?php if($conName[3] == 'googleanalytic'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.general_setting.googleanalytic')); ?>">Google Analytic</a>
                    <a class="collapse-item <?php if($conName[3] == 'googlerecaptcha'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.general_setting.googlerecaptcha')); ?>">Google Recaptcha</a>
                    <a class="collapse-item <?php if($conName[3] == 'tawklivechat'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.general_setting.tawklivechat')); ?>">Tawk Live Chat</a>
                    <a class="collapse-item <?php if($conName[3] == 'cookieconsent'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.general_setting.cookieconsent')); ?>">Cookie Consent</a>
                </div>
            </div>
        </li>


        <!-- Page Settings -->
        <li class="nav-item <?php if($conName[1] == 'page'): ?> active <?php endif; ?>">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePageSettings" aria-expanded="true" aria-controls="collapsePageSettings">
                <i class="fas fa-paste"></i>
                <span>Page Settings</span>
            </a>
            <div id="collapsePageSettings" class="collapse <?php if($conName[1] == 'page'): ?> show <?php endif; ?>" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item <?php if($conName[2] == 'home'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.page_home.edit')); ?>">Home</a>
                    <a class="collapse-item <?php if($conName[2] == 'about'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.page_about.edit')); ?>">About</a>
                    <a class="collapse-item <?php if($conName[2] == 'service'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.page_service.edit')); ?>">Service</a>
                    <a class="collapse-item <?php if($conName[2] == 'shop'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.page_shop.edit')); ?>">Shop</a>
                    <a class="collapse-item <?php if($conName[2] == 'blog'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.page_blog.edit')); ?>">Blog</a>
                    <a class="collapse-item <?php if($conName[2] == 'project'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.page_project.edit')); ?>">Project</a>
                    <a class="collapse-item <?php if($conName[2] == 'faq'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.page_faq.edit')); ?>">FAQ</a>
                    <a class="collapse-item <?php if($conName[2] == 'team'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.page_team.edit')); ?>">Team Member</a>
                    <a class="collapse-item <?php if($conName[2] == 'photo-gallery'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.page_photo_gallery.edit')); ?>">Photo Gallery</a>
                    <a class="collapse-item <?php if($conName[2] == 'video-gallery'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.page_video_gallery.edit')); ?>">Video Gallery</a>
                    <a class="collapse-item <?php if($conName[2] == 'contact'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.page_contact.edit')); ?>">Contact</a>
                    <a class="collapse-item <?php if($conName[2] == 'career'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.page_career.edit')); ?>">Career</a>
                    <a class="collapse-item <?php if($conName[2] == 'term'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.page_term.edit')); ?>">Term</a>
                    <a class="collapse-item <?php if($conName[2] == 'privacy'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.page_privacy.edit')); ?>">Privacy</a>
                    <a class="collapse-item <?php if($conName[2] == 'other'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.page_other.edit')); ?>">Other</a>
                </div>
            </div>
        </li>


        <!-- Footer Columns -->
        <li class="nav-item <?php if($conName[1] == 'footer'): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.footer.index')); ?>">
                <i class="fas fa-fw fa-list-alt"></i>
                <span>Footer Columns</span>
            </a>
        </li>

        <!-- Sliders -->
        <li class="nav-item <?php if($conName[1] == 'slider'): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.slider.index')); ?>">
                <i class="fas fa-sliders-h"></i>
                <span>Sliders</span>
            </a>
        </li>

        <!-- Blog Section -->
        <li class="nav-item <?php if($conName[1] == 'category' || $conName[1] == 'blog' || $conName[1] == 'comment'): ?> active <?php endif; ?>">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseBlog" aria-expanded="true" aria-controls="collapseBlog">
                <i class="fas fa-cubes"></i>
                <span>Blog Section</span>
            </a>
            <div id="collapseBlog" class="collapse <?php if($conName[1] == 'category' || $conName[1] == 'blog' || $conName[1] == 'comment'): ?> show <?php endif; ?>" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item" href="<?php echo e(route('admin.category.index')); ?>">Categories</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.blog.index')); ?>">Blogs</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.comment.approved')); ?>">Approved Comments</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.comment.pending')); ?>">Pending Comments</a>
                </div>
            </div>
        </li>

        <!-- Dynamic Pages -->
        <li class="nav-item <?php if($conName[1] == 'dynamic-page'): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.dynamic_page.index')); ?>">
                <i class="fas fa-cube"></i>
                <span>Dynamic Pages</span>
            </a>
        </li>

        <!-- Menu Manage -->
        <li class="nav-item <?php if($conName[1] == 'menu'): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.menu.index')); ?>">
                <i class="fas fa-bars"></i>
                <span>Menu Manage</span>
            </a>
        </li>

        <!-- Project -->
        <li class="nav-item <?php if($conName[1] == 'project'): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.project.index')); ?>">
                <i class="fas fa-umbrella"></i>
                <span>Project</span>
            </a>
        </li>

        <!-- Career Section -->
        <li class="nav-item <?php if($conName[1] == 'job' || $conName[1] == 'job-application'): ?> active <?php endif; ?>">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCareer" aria-expanded="true" aria-controls="collapseCareer">
                <i class="fas fa-user-secret"></i>
                <span>Career Section</span>
            </a>
            <div id="collapseCareer" class="collapse <?php if($conName[1] == 'job' || $conName[1] == 'job-application'): ?> show <?php endif; ?>" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item" href="<?php echo e(route('admin.job.index')); ?>">Jobs</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.job.view_application')); ?>">Job Applications</a>
                </div>
            </div>
        </li>


        <!-- Photo Gallery -->
        <li class="nav-item <?php if($conName[1] == 'photo-gallery'): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.photo.index')); ?>">
                <i class="fas fa-camera"></i>
                <span>Photo Gallery</span>
            </a>
        </li>

        <!-- Video Gallery -->
        <li class="nav-item <?php if($conName[1] == 'video-gallery'): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.video.index')); ?>">
                <i class="fas fa-video"></i>
                <span>Video Gallery</span>
            </a>
        </li>

        <!-- Product Section -->
        <li class="nav-item <?php if($conName[1] == 'product' || $conName[1] == 'shipping' || $conName[1] == 'coupon'): ?> active <?php endif; ?>">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseProduct" aria-expanded="true" aria-controls="collapseProduct">
                <i class="fas fa-shopping-cart"></i>
                <span>Product Section</span>
            </a>
            <div id="collapseProduct" class="collapse <?php if($conName[1] == 'product' || $conName[1] == 'shipping' || $conName[1] == 'coupon'): ?> show <?php endif; ?>" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item" href="<?php echo e(route('admin.product.index')); ?>">Product</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.shipping.index')); ?>">Shipping</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.coupon.index')); ?>">coupon</a>
                </div>
            </div>
        </li>

        <!-- Order -->
        <li class="nav-item <?php if($conName[1] == 'order'): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.order.index')); ?>">
                <i class="fas fa-bookmark"></i>
                <span>Order Section</span>
            </a>
        </li>

        <!-- Customer -->
        <li class="nav-item <?php if($conName[1] == 'customer'): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.customer.index')); ?>">
                <i class="fas fa-users"></i>
                <span>Customer Section</span>
            </a>
        </li>

        <!-- Why Choose Us -->
        <li class="nav-item <?php if($conName[1] == 'why-choose'): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.why_choose.index')); ?>">
                <i class="fas fa-arrows-alt"></i>
                <span>Why Choose Us</span>
            </a>
        </li>

        <!-- Services -->
        <li class="nav-item <?php if($conName[1] == 'service'): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.service.index')); ?>">
                <i class="fas fa-certificate"></i>
                <span>Service</span>
            </a>
        </li>

        <!-- Services -->
        <li class="nav-item <?php if($conName[1] == 'testimonial'): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.testimonial.index')); ?>">
                <i class="fas fa-award"></i>
                <span>Testimonial</span>
            </a>
        </li>

        <!-- Team Members -->
        <li class="nav-item <?php if($conName[1] == 'team-member'): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.team_member.index')); ?>">
                <i class="fas fa-user-plus"></i>
                <span>Team Member</span>
            </a>
        </li>

        <!-- FAQ -->
        <li class="nav-item <?php if($conName[1] == 'faq'): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.faq.index')); ?>">
                <i class="fas fa-question-circle"></i>
                <span>FAQ</span>
            </a>
        </li>

        <!-- Email Template -->
        <li class="nav-item <?php if($conName[1] == 'email-template'): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.email_template.index')); ?>">
                <i class="fas fa-envelope"></i>
                <span>Email Template</span>
            </a>
        </li>

        <!-- Subscriber -->
        <li class="nav-item <?php if($conName[1] == 'subscriber'): ?> active <?php endif; ?>">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSubscriber" aria-expanded="true" aria-controls="collapseSubscriber">
                <i class="fas fa-share-alt-square"></i>
                <span>Subscriber Section</span>
            </a>
            <div id="collapseSubscriber" class="collapse <?php if($conName[1] == 'subscriber'): ?> show <?php endif; ?>" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item" href="<?php echo e(route('admin.subscriber.index')); ?>">All Subscribers</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.subscriber.send_email')); ?>">Send Email to Subscribers</a>
                </div>
            </div>
        </li>

        <!-- Social Media -->
        <li class="nav-item <?php if($conName[1] == 'social-media'): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.social_media.index')); ?>">
                <i class="fas fa-basketball-ball"></i>
                <span>Social Media</span>
            </a>
        </li>



        <!-- Divider -->
        <hr class="sidebar-divider">

        <!-- Sidebar Toggler (Sidebar) -->
        <div class="text-center d-none d-md-inline">
            <button class="rounded-circle border-0" id="sidebarToggle"></button>
        </div>
    </ul>
    <!-- End of Sidebar -->


    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
            <!-- Topbar -->
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                <!-- Sidebar Toggle (Topbar) -->
                <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                    <i class="fa fa-bars"></i>
                </button>

                <!-- Topbar Navbar -->
                <ul class="navbar-nav ml-auto">


                    <!-- Nav Item - Alerts -->
                    <li class="nav-item dropdown no-arrow mx-1">
                        <a class="btn btn-info btn-sm mt-3" href="<?php echo e(url('/')); ?>" target="_blank">
                            Visit Website
                        </a>
                    </li>

                    <div class="topbar-divider d-none d-sm-block"></div>
                    <!-- Nav Item - User Information -->
                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e(session('name')); ?></span>
                            <img class="img-profile rounded-circle" src="<?php echo e(asset('public/uploads/'.session('photo'))); ?>">
                        </a>
                        <!-- Dropdown - User Information -->
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('admin.profile_change')); ?>">
                                <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i> Change Profile
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('admin.password_change')); ?>">
                                <i class="fas fa-unlock-alt fa-sm fa-fw mr-2 text-gray-400"></i> Change Password
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('admin.photo_change')); ?>">
                                <i class="fas fa-image fa-sm fa-fw mr-2 text-gray-400"></i> Change Photo
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(route('admin.logout')); ?>">
                                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i> Logout
                            </a>
                        </div>
                    </li>
                </ul>
            </nav>
            <!-- End of Topbar -->
            <!-- Begin Page Content -->
            <div class="container-fluid">

                <?php echo $__env->yieldContent('admin_content'); ?>

            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- End of Main Content -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php echo $__env->make('admin.includes.scripts-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\cmsvilla\resources\views/admin/admin_layouts.blade.php ENDPATH**/ ?>