<?php $__env->startSection('content'); ?>
    <div class="page-banner" style="background-image: url(<?php echo e(asset('public/uploads/'.$g_setting->banner_service)); ?>)">
        <div class="bg-page"></div>
        <div class="text">
            <h1><?php echo e($service->name); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($service->name); ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $service->detail; ?>

                </div>
            </div>
            <div class="row service pt_0 pb_0">
                <?php $__currentLoopData = $service_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="service-item wow fadeInUp mb_30">
                            <div class="photo">
                                <a href="<?php echo e(url('service/'.$row->slug)); ?>"><img src="<?php echo e(asset('public/uploads/'.$row->photo)); ?>" alt=""></a>
                            </div>
                            <div class="text">
                                <h3><a href="<?php echo e(url('service/'.$row->slug)); ?>"><?php echo e($row->name); ?></a></h3>
                                <p><?php echo e($row->short_description); ?></p>
                                <div class="read-more">
                                    <a href="<?php echo e(url('service/'.$row->slug)); ?>">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <?php echo e($service_items->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\phpscriptpoint\cmsvilla\cmsvilla\cms\resources\views/pages/services.blade.php ENDPATH**/ ?>