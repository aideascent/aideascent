<link rel="stylesheet" href="<?php echo e(asset('public/backend/vendor/fontawesome-free/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/backend/css/sb-admin-2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/backend/vendor/datatables/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/backend/css/toastr.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/backend/css/jquery-ui.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/backend/css/jquery.timepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/backend/css/summernote-bs4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/backend/css/spacing.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/backend/css/style.css')); ?>">
<?php /**PATH D:\xampp\htdocs\phpscriptpoint\cmsvilla\cmsvilla\cms\resources\views/admin/includes/styles.blade.php ENDPATH**/ ?>